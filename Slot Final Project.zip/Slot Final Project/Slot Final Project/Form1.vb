﻿Public Class Form1
    Dim random As Integer
    Dim random2 As Integer
    Dim random3 As Integer
    Dim money As Integer
    Dim choice As Integer
    Dim Bonuschoice As Integer





    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        money = 1000


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Make the slot machine randomly chose a number or heart
        random = Int(Rnd() * 6) + 1
        random2 = Int(Rnd() * 6) + 1
        random3 = Int(Rnd() * 6) + 1
        money = money - 25
        LBMoney.Text = money
        If money <= 0 Then
            choice = MsgBox("You Are out Of Money!! Would you like to restart?", vbYesNo)
        End If
        If choice = vbYes Then
            Application.Restart()
        End If

        If choice = vbNo Then
            Application.Exit()
        End If

        If money >= 10000 Then
            MsgBox("YOU HAVE WON!! You are now $10,000 richer!!", MsgBoxStyle.OkOnly)

            If vbOK Then
                Application.Exit()
            End If
        End If

        If random = 1 Then
            PictureBox1.Image = My.Resources._1_removebg_preview
        End If
        If random = 2 Then
            PictureBox1.Image = My.Resources._2_removebg_preview
        End If
        If random = 3 Then
            PictureBox1.Image = My.Resources._3_removebg_preview
        End If
        If random = 4 Then
            PictureBox1.Image = My.Resources.OIP_removebg_preview
        End If
        If random = 5 Then
            PictureBox1.Image = My.Resources._5_removebg_preview
        End If
        'If random = 6 Then
        'PictureBox1.Image = My.Resources._6_removebg_preview
        'End If
        If random = 6 Then
            PictureBox1.Image = My.Resources.heart_removebg_preview
        End If
        'If random = 8 Then
        'PictureBox1.Image = My.Resources._8_removebg_preview
        ' End If
        'If random = 9 Then
        'PictureBox1.Image = My.Resources._9_removebg_preview
        ' End If
        'If random = 10 Then
        'PictureBox1.Image = My.Resources.heart_removebg_preview
        'End If

        If random2 = 1 Then
            PictureBox2.Image = My.Resources._1_removebg_preview
        End If
        If random2 = 2 Then
            PictureBox2.Image = My.Resources._2_removebg_preview
        End If
        If random2 = 3 Then
            PictureBox2.Image = My.Resources._3_removebg_preview
        End If
        If random2 = 4 Then
            PictureBox2.Image = My.Resources.OIP_removebg_preview
        End If
        If random2 = 5 Then
            PictureBox2.Image = My.Resources._5_removebg_preview
        End If
        'If random2 = 6 Then
        'PictureBox2.Image = My.Resources._6_removebg_preview
        'End If
        If random2 = 6 Then
            PictureBox2.Image = My.Resources.heart_removebg_preview
        End If
        'If random2 = 8 Then
        'PictureBox2.Image = My.Resources._8_removebg_preview
        'End If
        'If random2 = 9 Then
        'PictureBox2.Image = My.Resources._9_removebg_preview
        'End If
        'If random2 = 10 Then
        'PictureBox2.Image = My.Resources.heart_removebg_preview
        'End If

        If random3 = 1 Then
            PictureBox1.Image = My.Resources._1_removebg_preview
        End If
        If random = 2 Then
            PictureBox3.Image = My.Resources._2_removebg_preview
        End If
        If random3 = 3 Then
            PictureBox3.Image = My.Resources._3_removebg_preview
        End If
        If random3 = 4 Then
            PictureBox3.Image = My.Resources.OIP_removebg_preview
        End If
        If random3 = 5 Then
            PictureBox3.Image = My.Resources._5_removebg_preview
        End If
        'If random3 = 6 Then
        'PictureBox3.Image = My.Resources._6_removebg_preview
        'End If
        If random3 = 6 Then
            PictureBox3.Image = My.Resources.heart_removebg_preview
        End If
        'If random3 = 8 Then
        'PictureBox3.Image = My.Resources._8_removebg_preview
        'End If
        ' If random3 = 9 Then
        'PictureBox3.Image = My.Resources._9_removebg_preview
        'End If
        'If random3 = 10 Then
        'pictureBox3.Image = My.Resources.heart_removebg_preview
        'End If

        If random = random2 And random = random3 And random2 = random And random2 = random3 And random3 = random2 And random3 = random Then
            money = money + 150
        End If
        LBMoney.Text = money

        If random = 6 And random2 = 6 And random3 = 6 Then
            Label1.Visible = False
            Label2.Visible = False
            Label3.Visible = False
            Label4.Visible = False
            Label5.Visible = False
            Label6.Visible = False
            Label7.Visible = False
            Button1.Visible = False
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = False


            Label9.Visible = True
            Op1.Visible = True
            Op2.Visible = True
            Op3.Visible = True



        End If
    End Sub

    Private Sub Op1_Click(sender As Object, e As EventArgs) Handles Op1.Click
        money = Int(Rnd() * 10001) + 500

        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        Label6.Visible = True
        Label7.Visible = True
        Button1.Visible = True
        PictureBox1.Visible = True
        PictureBox2.Visible = True
        PictureBox3.Visible = True


        Label9.Visible = False
        Op1.Visible = False
        Op2.Visible = False
        Op3.Visible = False
    End Sub

    Private Sub Op2_Click(sender As Object, e As EventArgs) Handles Op2.Click
        money = Int(Rnd() * 10001) + 500
        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        Label6.Visible = True
        Label7.Visible = True
        Button1.Visible = True
        PictureBox1.Visible = True
        PictureBox2.Visible = True
        PictureBox3.Visible = True


        Label9.Visible = False
        Op1.Visible = False
        Op2.Visible = False
        Op3.Visible = False
    End Sub

    Private Sub Op3_Click(sender As Object, e As EventArgs) Handles Op3.Click
        money = Int(Rnd() * 10001) + 500

        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        Label6.Visible = True
        Label7.Visible = True
        Button1.Visible = True
        PictureBox1.Visible = True
        PictureBox2.Visible = True
        PictureBox3.Visible = True


        Label9.Visible = False
        Op1.Visible = False
        Op2.Visible = False
        Op3.Visible = False
    End Sub
End Class
